export class EUsers{
    email?:String
    password?:String
}