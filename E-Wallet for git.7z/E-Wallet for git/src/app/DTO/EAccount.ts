import { NgFormSelectorWarning } from '@angular/forms';

export class EAccount{
  firstName:String;
  lastName:String;
  email:String;
  phoneNo:String;
  password:String;
  balance:number;
}