export class ETransaction{
    action:string
    tDate:any
    amount:number
    recieverNumber:string

}