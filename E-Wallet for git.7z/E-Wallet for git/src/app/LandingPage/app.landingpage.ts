import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AccountService } from '../AccountService/accountService';
import { EAccount } from '../DTO/EAccount';

@Component({templateUrl:'app.landingpage.html',styleUrls: ['./landingpage.css']})
export class LandingPage{
    eAccount:EAccount;
constructor(private router:Router,private accountService:AccountService){
    
}
detailsOfCustomer=new FormGroup(
    {
      firstname:new FormControl('',Validators.required),
      lastname:new FormControl('',Validators.required),
      email:new FormControl('',[Validators.required,Validators.email]),
      phone:new FormControl('',Validators.required),
      password:new FormControl('',Validators.required),
      confirmpassword:new FormControl('',Validators.required)

    })

    submitRecords():void
    {
      if(!this.detailsOfCustomer.valid)
      {
        alert("Please fill all the fields properly")
        if(this.detailsOfCustomer.get('password').value != this.detailsOfCustomer.get('confirmpassword').value){
            alert("password and confirm password doesnt matched")
        }
      }
      else{
          console.log("register button pressed")
          this.eAccount={firstName:this.detailsOfCustomer.get('firstname').value,
                         lastName:this.detailsOfCustomer.get('lastname').value,
                         email:this.detailsOfCustomer.get('email').value,
                         phoneNo:this.detailsOfCustomer.get('phone').value,
                         password:this.detailsOfCustomer.get('password').value,
                        balance:0
                        }

          this.accountService.signuP(this.eAccount).subscribe(data=>{
              console.log(data)
              if(data){
                  alert("You have been succesfully registered,please login now")
              }
            });
          window.location.href="login"
    //   this.service.addCustomer(this.detailsOfCustomer.value).subscribe(data=>console.log(data));
    //   window.location.href="";

      }
    }



redToLogin(){
 this.router.navigate(["login"]);       
}
}