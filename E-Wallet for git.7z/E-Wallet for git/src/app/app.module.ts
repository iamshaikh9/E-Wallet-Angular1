import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';


import { HeaderComponent } from './header/app.header';

import { Homepage } from './Homepage/app.homepage';
import { HttpClientModule } from '@angular/common/http';
import { LandingPage } from './LandingPage/app.landingpage';
import { LoginComponent } from './Login/app.login';
import { ShowBalance } from './Showbalance/app.showbalance';
import { AddMoney } from './AddMoney/ap.addmoney';
import { TransferMoney } from './TransferMoney/app.transfermoney';
import { ShowTransactions } from './ShowTransactions/app.showtransactions';
import { MyProfile } from './MyProfile/app.myprofile';

@NgModule({
  declarations: [
    AppComponent,HeaderComponent,Homepage,LandingPage,LoginComponent,ShowBalance,AddMoney,TransferMoney,ShowTransactions,MyProfile
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,FormsModule,HttpClientModule,ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
