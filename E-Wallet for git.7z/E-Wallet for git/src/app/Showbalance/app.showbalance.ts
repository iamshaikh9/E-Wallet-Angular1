import { componentFactoryName } from '@angular/compiler';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from '../AccountService/accountService';
import { EAccount } from '../DTO/EAccount';

@Component({templateUrl:'app.showbalance.html'})
export class ShowBalance implements OnInit{
    balance:number
    eAccount:EAccount
constructor(private router:Router,private accountService:AccountService){

} 
    
ngOnInit(){
this.accountService.getUserDetails(localStorage.getItem("currentEId")).subscribe(data=>{
this.eAccount=<EAccount>data;
this.balance=this.eAccount.balance
})
}
}