import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from '../AccountService/accountService';
import { EAccount } from '../DTO/EAccount';
import { Observable } from 'rxjs';

@Component({templateUrl:'app.homepage.html',styleUrls:["./app.homepage.css"]})
export class Homepage implements OnInit{
constructor(private router:Router,private accountService:AccountService){

}    
emailId:String=''
EId:number;
eAccount:EAccount
ngOnInit(){
    localStorage.getItem("currentEId")
  
    this.accountService.getUserDetails(localStorage.getItem("currentEId")).subscribe(data=>{
     this.eAccount=<EAccount>data;
     console.log(this.eAccount)
     this.emailId=this.eAccount.email
    }); 

  
}


logOut(){
localStorage.removeItem("curerentEId")
this.router.navigate(["login"])
}
}