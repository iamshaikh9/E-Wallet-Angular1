import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


import { AppComponent } from './app.component';

import { Homepage } from './Homepage/app.homepage';
import { LandingPage } from './LandingPage/app.landingpage';
import { LoginComponent } from './Login/app.login';
import { ShowBalance } from './Showbalance/app.showbalance';
import { AddMoney } from './AddMoney/ap.addmoney';
import { TransferMoney } from './TransferMoney/app.transfermoney';
import { ShowTransactions } from './ShowTransactions/app.showtransactions';
import { MyProfile } from './MyProfile/app.myprofile';


const routes: Routes = [
  // {path: '',   redirectTo: './login', pathMatch: 'full'},
  {path:'',redirectTo: 'landingPage', pathMatch: 'full'},
  {path:'landingPage',component:LandingPage},
  {path:'login',component:LoginComponent },
  // {path:'signup',component:SignUpComponent },
  {path:'homepage',component:Homepage},
  {path:'showbalance',component:ShowBalance},
  {path:'addmoney',component:AddMoney},
  {path:'transfermoney',component:TransferMoney},
  {path:'showtransactions',component:ShowTransactions},
  {path:'myprofile',component:MyProfile}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
