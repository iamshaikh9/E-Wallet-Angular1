import { OnInit, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { EAccount } from '../DTO/EAccount';

// import { Http2Stream } from 'http2';
// import { HttpClient } from '@angular/common/http';
// import { EAccount } from '../DTO/EAccount';

// export class AccountService{
// constructor(private http:HttpClient){

// }

// public Login(eAccount:EAccount){
//     this.http.get('http://localhost:9090/login'+eAccount);
// }
// }
@Injectable({providedIn: 'root'})
export class AccountService implements OnInit{
    public users:any[];
    baseUrl:String
constructor(private http:HttpClient) {
    this.baseUrl='http://localhost:9090';
 }

 ngOnInit(){
     
 }


 //Signup
 public signuP(eAccount:EAccount){
   return this.http.post(`${this.baseUrl}/signUp`,eAccount);
 }

  public getAllAccounts(): Observable<any>{
    return this.http.get(`${this.baseUrl}/getAllAccount`);

  }

  public  authenticate(eAccount:EAccount) {
    console.log("authenticate angular called"+eAccount);
    return this.http.post(`${this.baseUrl}/authenticate`,eAccount)

    }

  public getUserDetails(EId){
    return this.http.get(`${this.baseUrl}/getAccount/`+EId);
  }

  public addMoney(EId,amount){
    let eAccount:EAccount=new EAccount();
    eAccount.balance=amount;
    return this.http.post(`${this.baseUrl}/addMoney/`+EId,eAccount,{responseType: 'text'});
  }


  public transferMoney(EId,ReciversPhoneNumber,amount){
    let eAccount:EAccount=new EAccount();
    eAccount.balance=amount;
    eAccount.phoneNo=ReciversPhoneNumber
    console.log(eAccount)
    return this.http.post(`${this.baseUrl}/transferMoney/`+EId,eAccount,{responseType: 'text'});
  }

  public getTransactions(EId){
    return this.http.get(`${this.baseUrl}/getTransactions/`+EId);
  }

    logout() {
      // remove user from local storage to log user out
      localStorage.removeItem('currentEId');
     }
    
    // if (username === "javainuse" && password === "password") {
    //   sessionStorage.setItem('username', username)
    //   return true;
    // } else {
    //   return false;
    // }
  

  // isUserLoggedIn() {
  //   let user = sessionStorage.getItem('username')
  //   console.log(!(user === null))
  //   return !(user === null)
  // }

  // logOut() {
  //   sessionStorage.removeItem('username')
  // }
  
}