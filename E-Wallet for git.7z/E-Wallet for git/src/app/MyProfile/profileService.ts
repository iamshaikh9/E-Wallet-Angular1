import { Injectable, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { EAccount } from '../DTO/EAccount';

@Injectable({providedIn: 'root'})
export class profileService implements OnInit{
    baseUrl:any
   
    constructor(private http:HttpClient){
        this.baseUrl='http://localhost:9090';
    }
    ngOnInit(){

    }

 public updateFName(EId,newFirstName){
     let eAccount:EAccount =new EAccount();
     eAccount.firstName=newFirstName;
 
   this.http.put(`${this,this.baseUrl}/updateFName/`+EId,eAccount).subscribe();
   location.reload();
}

}