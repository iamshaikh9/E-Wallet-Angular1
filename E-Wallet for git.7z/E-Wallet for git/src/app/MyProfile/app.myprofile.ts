import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from '../AccountService/accountService';
import { EAccount } from '../DTO/EAccount';
import { profileService } from './profileService';

@Component({templateUrl:'app.myprofile.html',styleUrls:['app.myprofile.css']})
export class MyProfile implements OnInit{
    eAccount:EAccount;
    isdisabledfn:boolean=true;
    isdisabledln:boolean=true;
    isdisabledem:boolean=true
    isdisabledph:boolean=true


    newFirstName:any
    newLastName:any
    newEmail:any
    newPhoneno:any

    constructor(private router:Router,private accoountService:AccountService,private profileService:profileService){

    }
    ngOnInit(){
        this.accoountService.getUserDetails(localStorage.getItem("currentEId")).subscribe(data=>{
            this.eAccount=<EAccount>data;
        })
    }


    //Edit Buttons

    editFirstName(){
        console.log("edit button clickede")
        this.isdisabledfn=false;
    }

    editLastName(){
        console.log("edit button clickede")
        this.isdisabledln=false;
    }

    editEmail(){
        console.log("edit button clickede")
        this.isdisabledem=false;
    }

    editPhoneNO(){
        console.log("edit button clickede")
        this.isdisabledph=false;
    }

    //Update Buttons
    updateFirstName(){
      if(this.newFirstName==null){
          console.log("no value changed")
      }
      console.log(this.newFirstName)
      this.profileService.updateFName(localStorage.getItem("currentEId"),this.newFirstName);
      
    }
    updateLastName(){
      console.log(this.newLastName)
    }
    updateEmail(){
console.log(this.newEmail)
    }
    updatePhoneNo(){
console.log(this.newPhoneno)
    }



}