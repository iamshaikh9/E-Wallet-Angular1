import { Component } from "@angular/core";
import { Router } from '@angular/router';
import { AccountService } from '../AccountService/accountService';

@Component({templateUrl:'app.addmoney.html'})
export class AddMoney{
amount:number;

constructor(private route:Router,private accountService:AccountService){
console.log(this.amount)
}
addMoney(){
    this.accountService.addMoney(localStorage.getItem("currentEId"),this.amount).subscribe(data=>{
    if(data){
      console.log(data)  
      alert("Money Added");
      this.route.navigate(["showbalance"]);
    }
    });
}


}