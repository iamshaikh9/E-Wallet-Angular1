import { Component, OnInit } from '@angular/core';
import { ETransaction } from '../DTO/ETransaction';
import { Router } from '@angular/router';
import { AccountService } from '../AccountService/accountService';

@Component({templateUrl:'app.showtransactions.html'})
export class ShowTransactions implements OnInit{
    Transactions:ETransaction[];

    constructor(private router:Router,private accountService:AccountService){}
    ngOnInit(){
        this.accountService.getTransactions(localStorage.getItem("currentEId")).subscribe(data=>{
            console.log(data)
         this.Transactions=<ETransaction[]>data
        })
    }

}