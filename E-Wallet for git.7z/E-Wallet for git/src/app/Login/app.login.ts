import { Component } from "@angular/core";
import { Router } from '@angular/router';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { AccountService } from '../AccountService/accountService';
import { EAccount } from '../DTO/EAccount';

@Component({templateUrl:"app.login.html",styleUrls:["./app.login.css"]})
export class LoginComponent{
  eAccount:EAccount={email:'',password:'',firstName:'',lastName:'',phoneNo:'',balance:0};
constructor(private router:Router,private accountService:AccountService){

}

loginForm=new FormGroup(
    {
      emailorphone:new FormControl('',Validators.required),
      password:new FormControl('',Validators.required)


    })

    submit(){
      console.log("Submit clicked")
      this.eAccount.email=this.loginForm.get('emailorphone').value;
      console.log(this.eAccount);
      this.eAccount.phoneNo=this.loginForm.get('emailorphone').value;
      this.eAccount.password=this.loginForm.get('password').value;
      this.accountService.authenticate(this.eAccount).subscribe(data=>{
        if(data==null){
            this.router.navigate(["login"])
        }
        else{
            let EId:any;
            EId=data;
            localStorage.setItem("currentEId",EId);
            this.router.navigate(["homepage"])

        }

      })
    }


redToSignUp(){
    this.router.navigate(['landingPage'])
}
}