import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { AccountService } from '../AccountService/accountService';
import { ShowBalance } from '../Showbalance/app.showbalance';

@Component({templateUrl:'app.tranfermoney.html'})
export class TransferMoney{
    mobileNo:number
    amount:number
constructor(private router:Router,private accountService:AccountService){}
transferMoney(){
    console.log(localStorage.getItem("currentEId"))
    console.log(this.mobileNo)
    console.log(this.amount)
    this.accountService.transferMoney(localStorage.getItem("currentEId"),this.mobileNo,this.amount).subscribe(data=>{
        if(data){
        console.log(data)
        alert("Money transferred");
        this.router.navigate(['showbalance'])
        }
    })
}
}

